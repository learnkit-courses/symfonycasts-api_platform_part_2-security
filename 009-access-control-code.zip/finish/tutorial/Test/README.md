This directory is copy of the Test directory from API Platform
as of commit sha [4f37297cb40](https://github.com/api-platform/core/commit/4f37297cb40a09dd0e939e39fe53038e60a53699)
on October 7th, 2019: https://github.com/api-platform/core/tree/master/src/Bridge/Symfony/Bundle/Test

At the time of copying this, these testing features were unreleased.
So, we're copying them into our project (against my better judgment)
so we can use them in our project and see how they work!
